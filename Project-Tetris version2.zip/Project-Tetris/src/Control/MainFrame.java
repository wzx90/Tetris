package Control;
import Data.GameData;
import Data.Record;
import UI.MainWindow;
import UI.StartInterfacenew;

import javax.swing.*;
import java.awt.*;
import java.util.Collections;

//控制层与层之间的关系
public class MainFrame
{
    public MainFrame(GameData gameData)
    {
        //实例化操作
        Operation operation = new Operation();
        //将数据和窗口进行关联
        MainWindow mainWindow = new MainWindow(operation, gameData);
        //将窗口和操作进行关联，用键盘操作
        operation.setWindow(mainWindow);
        //将数据和操作进行关联
        operation.setData(gameData);
        //启用线程
        new AutoDown(gameData, mainWindow).start();

        mainWindow.getGameFrame().setVisible(true);//显示窗口
    }
}

//方块自动下落
class AutoDown extends Thread//继承一个线程
{
    private GameData gameData;
    private MainWindow mainWindow;
    AutoDown(GameData gameData, MainWindow mainWindow)
    {
        this.gameData = gameData;
        this.mainWindow = mainWindow;
    }
    public void run() {
        while (true) {
            try {
                if (gameData.state == 1)//游戏中状态
                {
                    if (gameData.move(false, 1))
                    {
                        mainWindow.getScoreNextPanel().repaint();//刷新得分和提示区
                    }
                    mainWindow.getGamePanel().repaint();//刷新游戏区
                    sleep(gameData.fallSpeed);
                }
                else if (gameData.state == 3)//结束状态
                {
                    gameData.records.add(new Record(gameData.name, gameData.score));
                    Collections.sort(gameData.records);
                    gameData.saveRecord();
                    mainWindow.end("Your Score is : " + gameData.score);
                    gameData.initialGameData();
                    mainWindow.getGameFrame().dispose();
                    new StartInterfacenew();
                }
                else { sleep(200);}
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }


}


