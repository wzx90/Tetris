package Control;
import Data.GameData;
import UI.GamePanel;
import UI.ImageButton;
import UI.MainWindow;
import UI.StartInterfacenew;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Operation
{
    MainWindow mainWindow;
    GameData gameData;
    public ImageButton left;
    public ImageButton right;
    public ImageButton rotate;
    public ImageButton down;
    public JButton button1;
    public JButton save;
    public JButton exit;

    static String path = System.getProperty("user.dir");//调取所在project路径

    public Operation()
    {
        buttonOperation();
    }

    public void buttonOperation()
    {
        //下左右移动和旋转
        left = new ImageButton(new ImageIcon("Project-Tetris\\Image\\left.png"));
        left.addActionListener(a->
        {
            if(gameData.state == 1)
            {
                gameData.move(true, -1);
                mainWindow.getGamePanel().repaint();
            }
        });
        right = new ImageButton(new ImageIcon("Project-Tetris\\Image\\right.png"));
        right.addActionListener(a->
        {
            if(gameData.state == 1)
            {
                gameData.move(true, 1);
                mainWindow.getGamePanel().repaint();
            }
        });
        down= new ImageButton(new ImageIcon("Project-Tetris\\Image\\down.png"));
        down.addActionListener(a->
        {
            if(gameData.state == 1)
            {
                if(gameData.move(false, 1))//方块组落地为true
                {
                    mainWindow.getScoreNextPanel().repaint();//方块组落地刷新得分
                }
                    mainWindow.getGamePanel().repaint();//刷新游戏区
            }
        });
        rotate = new ImageButton(new ImageIcon("Project-Tetris\\Image\\rotate.png"));
        rotate.addActionListener(a->
        {
            if(gameData.state == 1)
            {
                gameData.rotate();
                mainWindow.getGamePanel().repaint();
            }
        });
        button1 = new JButton("Start");
        button1.addActionListener(a->
        {
            if (gameData.state == 1){ gameData.state = 2; pauseFrame();}
            else { gameData.state = 1;}
            button1.setText(gameData.button1Choices[gameData.state]);
        });
        save = new JButton("Save");
        save.addActionListener(a->
        {
            if (gameData.state == 1){ gameData.state = 2; saveFrame();}
        });

        exit = new JButton("Exit");
        exit.addActionListener(a->
        {
            if(gameData.state != 2)
            {
                gameData.saveRecord();
                gameData.state = 0;
                mainWindow.getGameFrame().dispose();
                new StartInterfacenew();
            }
        });
    }

    //点击pause后的弹窗
    public void pauseFrame(){
        JFrame choices = new JFrame();
        choices.setTitle("Choices");
        choices.setLocation(600, 250);
        choices.setSize(250, 400);
        choices.setVisible(true);
        choices.setLayout(null);

        ImageIcon imageIcon = new ImageIcon("Project-Tetris\\Image\\back.png");
        JLabel jLabel = new JLabel(imageIcon);
        jLabel.setBounds(0,0,250,400);
        choices.getContentPane().add(jLabel);

        JLabel txt1 = new JLabel();
        txt1.setText("Please Select A Choice");
        txt1.setLocation(48,5);
        txt1.setSize(320, 80);
        txt1.setVisible(true);
        choices.getLayeredPane().add(txt1);

        JButton Continue = new JButton("Continue");
        Continue.setLocation(35, 80);
        Continue.setSize(160, 50);
        Continue.setFocusPainted(false);
        choices.getLayeredPane().add(Continue);
        Continue.addActionListener(a -> {
            choices.dispose();
            gameData.state = 1;
            button1.setText(gameData.button1Choices[gameData.state]);
        });

        JButton Restart = new JButton("Restart");
        Restart.setLocation(35, 140);
        Restart.setSize(160, 50);
        Restart.setFocusPainted(false);
        choices.getLayeredPane().add(Restart);
        Restart.addActionListener(a -> {
            gameData.saveRecord();
            choices.dispose();
            gameData.initialGameData();
            gameData.readRecord();
            gameData.state = 1;
            mainWindow.getGameFrame().repaint();
            button1.setText(gameData.button1Choices[gameData.state]);
        });

        JButton Save = new JButton("Save");
        Save.setLocation(35, 200);
        Save.setSize(160, 50);
        Save.setFocusPainted(false);
        choices.getLayeredPane().add(Save);
        Save.addActionListener(a -> {
            choices.dispose();
            saveFrame();
        });

        JButton Exit = new JButton("Exit");
        Exit.setLocation(35, 260);
        Exit.setSize(160, 50);
        Exit.setFocusPainted(false);
        choices.getLayeredPane().add(Exit);
        Exit.addActionListener(a -> {
            gameData.saveRecord();
            choices.dispose();
            mainWindow.getGameFrame().dispose();
            new StartInterfacenew();
        });
    }

    //点击save后的弹窗
    public void saveFrame(){
        gameData.saveRecord();

        JFrame Save = new JFrame();
        Save.setTitle("Save Game");
        Save.setLocation(550, 300);
        Save.setSize(360, 210);
        Save.setVisible(true);
        Save.setLayout(null);

        JLabel txt1 = new JLabel();
        txt1.setText("Please Input A File Name To Save Your Game");
        txt1.setSize(360, 30);
        txt1.setLocation(5, 5);
        txt1.setVisible(true);
        Save.add(txt1);

        JTextField save = new JTextField();
        save.setLocation(5, 40);
        save.setSize(335, 30);
        Save.add(save);

        JButton OK = new JButton("OK");
        OK.setLocation(30, 90);
        OK.setSize(130, 40);
        OK.setFocusPainted(false);
        Save.add(OK);
        OK.addActionListener(a -> {
            String fileName = save.getText();
            saveDataToFile(fileName);
            Save.dispose();
            mainWindow.getGameFrame().dispose();
            new StartInterfacenew();
        });

        JButton Cancel = new JButton("Cancel");
        Cancel.setLocation(180, 90);
        Cancel.setSize(130, 40);
        Cancel.setFocusPainted(false);
        Save.add(Cancel);
        Cancel.addActionListener(a -> {
            Save.dispose();
            gameData.state = 1;
        });
    }

    public void saveDataToFile(String fileName) {
        try {
            FileWriter fileWriter = new FileWriter(path + "/Project-Tetris/Saves/" + fileName + ".txt");
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(String.valueOf(gameData.name));
            bufferedWriter.newLine();
            bufferedWriter.write(String.valueOf(gameData.score));
            bufferedWriter.newLine();
            bufferedWriter.write(String.valueOf(gameData.state));
            bufferedWriter.newLine();
            bufferedWriter.write(String.valueOf(gameData.fallSpeed));
            bufferedWriter.newLine();
            bufferedWriter.write(String.valueOf(gameData.x));
            bufferedWriter.newLine();
            bufferedWriter.write(String.valueOf(gameData.y));
            bufferedWriter.newLine();
            bufferedWriter.write(String.valueOf(gameData.current));
            bufferedWriter.newLine();
            bufferedWriter.write(String.valueOf(gameData.next));
            bufferedWriter.newLine();
            for (int i = 37; i >= 0; i--) {
                for (int j = 0; j < 20; j++) {
                    bufferedWriter.write(gameData.existBlocks[j][i] + " ");
                }
                bufferedWriter.newLine();
            }
            bufferedWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //关联窗口
    //将按键输入到窗口，而不是panel和button
    public void setWindow(MainWindow mainWindow)
    {
        this.mainWindow = mainWindow;
        //取消按钮截获按键
        button1.setFocusable(false);
        save.setFocusable(false);
        exit.setFocusable(false);
        this.mainWindow.getGameFrame().addKeyListener(new KeyListener() {
            public void keyTyped(KeyEvent e) {}
            public void keyPressed(KeyEvent e)
            {
                switch (e.getKeyCode())
                {
                    case KeyEvent.VK_LEFT:
                        if(gameData.state == 1)
                        {
                            gameData.move(true, -1);
                            mainWindow.getGamePanel().repaint();
                        }
                        break;
                    case KeyEvent.VK_RIGHT:
                        if(gameData.state == 1)
                        {
                            gameData.move(true, 1);
                            mainWindow.getGamePanel().repaint();
                        }
                        break;
                    case KeyEvent.VK_DOWN:
                        if (gameData.state == 1)
                        {
                            if(gameData.move(false, 1))//方块组落地为true
                            {
                                mainWindow.getScoreNextPanel().repaint();//方块组落地刷新得分
                            }
                            mainWindow.getGamePanel().repaint();
                        }
                        break;
                    case KeyEvent.VK_UP:
                        if(gameData.state == 1)
                        {
                            gameData.rotate();
                            mainWindow.getGamePanel().repaint();
                        }
                        break;
                    case KeyEvent.VK_SPACE:
                        if (gameData.state == 1){ gameData.state = 2; pauseFrame();}
                        else { gameData.state = 1;}
                        button1.setText(gameData.button1Choices[gameData.state]);
                        break;
                }
            }
            public void keyReleased(KeyEvent e) {
            }
        });
    }

    //关联数据
    public void setData(GameData gameData)
    {
        this.gameData = gameData;
    }
}


