package Data;

public class Record implements Comparable<Record>
{
    private String name;
    private int score;
    public Record(String name, int score)
    {
        this.name = name;
        this.score = score;
    }

    public String toString()
    {
        return String.format("%-21s%d", name, score );
    }

    public String getName(){return name;}
    public int getScore()
    {
        return score;
    }

    public int compareTo(Record record)
    {
        if (score > record.getScore()){return 1;}
        if (score < record.getScore()){return -1;}
        else {return 0;}
    }
}
