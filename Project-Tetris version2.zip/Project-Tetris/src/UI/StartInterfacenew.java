package UI;
import Control.MainFrame;
import Data.GameData;

import javax.swing.*;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;

public class StartInterfacenew   {
    JFrame StartInterface;
    JButton newgame;
    JButton loadgame;
    JButton login;
    ImageIcon imagic;

    GameData gameData;

    public StartInterfacenew(){
        StartInterface = new JFrame("Tetris");
        StartInterface.setBounds(550,100,360,640);
        StartInterface.setLayout(null);
        StartInterface.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        StartInterface.setVisible(true);

        imagic=new ImageIcon("Project-Tetris\\Image\\start.png");
        JLabel j = new JLabel(imagic);
        j.setBounds(0,0,360,640);
        StartInterface.getContentPane().add(j);

        StartInterface.setResizable(false);

        gameData = new GameData();
        gameData.readRecord();
        Collections.sort(gameData.records);

        newgame=new JButton("NEW GAME");
        newgame.setBounds(115,320,130,40);
        newgame.setFocusPainted(false);
        StartInterface.getLayeredPane().add(newgame);
        newgame.addActionListener(e -> {
            startnewgame();
        });

        loadgame=new JButton("LOAD GAME");
        loadgame.setBounds(115,380,130,40);
        loadgame.setFocusPainted(false);
        StartInterface.getLayeredPane().add(loadgame);
        loadgame.addActionListener(e -> {
            Load();
        });

        login=new JButton("LOG IN");
        login.setBounds(115,440,130,40);
        login.setFocusPainted(false);
        StartInterface.getLayeredPane().add(login);
        login.addActionListener(e -> {
            Login();
        });
    }

    public void Load(){
        JFrame Load = new JFrame();
        Load.setTitle("Load Game");
        Load.setLocation(550, 300);
        Load.setSize(360, 210);
        Load.setVisible(true);
        Load.setLayout(null);

        JLabel txt1 = new JLabel();
        txt1.setText("Please Input The Record File Name To Load Your Game");
        txt1.setSize(360, 30);
        txt1.setLocation(5, 5);
        txt1.setVisible(true);
        Load.add(txt1);

        JTextField load = new JTextField();
        load.setLocation(5, 40);
        load.setSize(335, 30);
        Load.add(load);


        JButton OK = new JButton("OK");
        OK.setLocation(30, 90);
        OK.setSize(130, 40);
        OK.setFocusPainted(false);
        Load.add(OK);
        OK.addActionListener(a -> {
            Load.dispose();
            StartInterface.dispose();
        });

        JButton Cancel = new JButton("Cancel");
        Cancel.setLocation(180, 90);
        Cancel.setSize(130, 40);
        Cancel.setFocusPainted(false);
        Load.add(Cancel);
        Cancel.addActionListener(a -> {
            Load.dispose();
        });

    }

    public void Login(){
        JFrame LogIn = new JFrame();
        LogIn.setTitle("Log In");
        LogIn.setLocation(550, 300);
        LogIn.setSize(360, 210);
        LogIn.setVisible(true);
        LogIn.setLayout(null);

        JLabel txt1 = new JLabel();
        txt1.setText("Please Input Your Name");
        txt1.setSize(360, 30);
        txt1.setLocation(5, 5);
        txt1.setVisible(true);
        LogIn.add(txt1);

        JTextField save = new JTextField();
        save.setLocation(5, 40);
        save.setSize(335, 30);
        LogIn.add(save);


        JButton OK = new JButton("OK");
        OK.setLocation(30, 90);
        OK.setSize(130, 40);
        OK.setFocusPainted(false);
        LogIn.add(OK);
        OK.addActionListener(a -> {
            LogIn.dispose();
            gameData.name = save.getText();
        });

        JButton Cancel = new JButton("Cancel");
        Cancel.setLocation(180, 90);
        Cancel.setSize(130, 40);
        Cancel.setFocusPainted(false);
        LogIn.add(Cancel);
        Cancel.addActionListener(a -> {
            LogIn.dispose();
        });
    }

    public void startnewgame(){
        JFrame Newgamemodle = new JFrame();
        Newgamemodle.setTitle("Choice");
        Newgamemodle.setLocation(600, 300);
        Newgamemodle.setSize(260, 300);
        Newgamemodle.setVisible(true);
        Newgamemodle.setLayout(null);

        JButton Easy = new JButton("Easy");
        Easy.setLocation(58, 30);
        Easy.setSize(130, 50);
        Easy.setFocusPainted(false);
        Newgamemodle.add(Easy);
        Easy.addActionListener(a -> {
            Newgamemodle.dispose();
            StartInterface.dispose();
            gameData.fallSpeed = 200;
            new MainFrame(gameData);

        });
        JButton Hard = new JButton("Hard");
        Hard.setLocation(58, 100);
        Hard.setSize(130, 50);
        Hard.setFocusPainted(false);
        Newgamemodle.add(Hard);
        Hard.addActionListener(a -> {
            Newgamemodle.dispose();
            StartInterface.dispose();
            gameData.fallSpeed = 100;
            new MainFrame(gameData);
        });
        JButton Hell = new JButton("Hell");
        Hell.setLocation(58, 170);
        Hell.setSize(130, 50);
        Hell.setFocusPainted(false);
        Newgamemodle.add(Hell);
        Hell.addActionListener(a -> {
            Newgamemodle.dispose();
            StartInterface.dispose();
            gameData.fallSpeed = 50;
            new MainFrame(gameData);
        });
    }
}




