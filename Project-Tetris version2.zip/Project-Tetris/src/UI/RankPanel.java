package UI;
import Data.GameData;
import javax.swing.*;
import java.awt.*;

//游戏界面
public class RankPanel extends JPanel {
    GameData gameData;

    public RankPanel(GameData gameData) {
        this.gameData = gameData;
        setOpaque(false);//设置画布透明
        setBounds(15, 405, 200, 170);
    }

    public void paintComponent(Graphics graphics) {
        graphics.setFont(new Font("Times New Roman", Font.BOLD, 20));
        if (gameData.records.size() > 0 && gameData.records.size() < 5)
        {
            for (int i = gameData.records.size() - 1; i >= 0; i--)
            {
                graphics.drawString(gameData.records.get(i).getName(), 10,  25 + 25 * (gameData.records.size() - i));
                graphics.drawString(String.valueOf(gameData.records.get(i).getScore()), 165,  25 + 25 * (gameData.records.size() - i));
            }
        }
        if(gameData.records.size() >= 5)
        {
            for (int i = gameData.records.size() - 1; i >= gameData.records.size() - 5; i--)
            {
                graphics.drawString(gameData.records.get(i).getName(), 10,  25 + 25 * (gameData.records.size() - i));
                graphics.drawString(String.valueOf(gameData.records.get(i).getScore()), 165,  25 + 25 * (gameData.records.size() - i));
            }
        }
        else{}
    }
}



