import Data.Record;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class test
{
    public static void main(String[] args) {
        System.out.println("aaa" +String.format("%23s", "") + 2);
    }
}
